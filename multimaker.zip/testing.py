z is None

if z != 11:
    print("works")

